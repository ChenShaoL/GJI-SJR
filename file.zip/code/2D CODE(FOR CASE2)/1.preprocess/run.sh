mima='111111'
mpif90 -c PRE2D.F90
mpif90 -o P.EXE PRE2D.o
echo ${mima} | sudo -S mpiexec -n 1 --allow-run-as-root P.EXE
