mima='111111'
mpif90 -c PSVFREE2D-WATER-DRY.F
mpif90 -o P.EXE PSVFREE2D-WATER-DRY.o
echo ${mima} | sudo -S mpiexec -n 1 --allow-run-as-root P.EXE
